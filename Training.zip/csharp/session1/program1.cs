class Sum2{
    static void Main(string[] args){
        int num, sum=0,n;
        Console.Write("Enter the limit");
        n=Int32.Parse(Console.ReadLine());
        for(int i=0;i<n;i++){
            Console.WriteLine("Enter the number");
            num=Int32.Parse(Console.ReadLine());
            sum += num;
        }
        Console.WriteLine($"sum is: {sum}");
    } 
}
