﻿//fibo prog
class Fib
{
    static void main()
    {
        int a = 0;
        int b = 1;
        int c;
        Console.Write(a);
        Console.Write(" "+b+" ");
        for (int i = 3; i <= 10; i++)
        {
            c = a + b;
            Console.Write(c+" ");
            a = b;
            b = c;
        }
    }
}
